export class Image{
    ID:number;
    WordID:number;
    Name:string;
    url:string;
}